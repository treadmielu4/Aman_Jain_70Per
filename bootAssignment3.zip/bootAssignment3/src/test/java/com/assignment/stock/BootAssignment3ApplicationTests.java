package com.assignment.stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootAssignment3ApplicationTests {

	@Test
	void contextLoads() {
	}

}

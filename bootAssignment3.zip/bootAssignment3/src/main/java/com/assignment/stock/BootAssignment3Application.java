package com.assignment.stock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootAssignment3Application {

	public static void main(String[] args) {
		SpringApplication.run(BootAssignment3Application.class, args);
	}

}

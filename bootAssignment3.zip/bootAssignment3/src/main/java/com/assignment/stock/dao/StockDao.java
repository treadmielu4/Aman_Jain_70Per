package com.assignment.stock.dao;

public interface StockDao {

}

package com.assignment.stock.model;

public class Stock {

}

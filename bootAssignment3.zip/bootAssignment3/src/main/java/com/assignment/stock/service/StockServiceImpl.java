package com.assignment.stock.service;

public class StockServiceImpl {

}

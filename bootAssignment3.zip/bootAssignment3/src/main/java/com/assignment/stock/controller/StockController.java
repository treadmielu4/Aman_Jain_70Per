package com.assignment.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.assignment.stock.model.Stock;
import com.assignment.stock.service.StockService;

public class StockController {
	@Autowired
	StockService stockservice;
	
	
	@GetMapping(value = "/getAllStock")
	Iterable<Stock> getAllStock() {
        return stockservice.findAllStock();
        
    }
	@GetMapping(value = "/topFive")
	Iterable<Stock> topFiveStockByPrice() {
        return stockservice.topFiveStock();
        
    }
	@GetMapping(value = "/searchStockByCompany/{companyName}")
	Iterable<Stock> searchStockByCompany(@PathVariable String companyName) {
        return stockservice.stockByCompanyName(companyName);
        
    }
	@GetMapping(value = "/topFiveStockByCompanyRanking")
	Iterable<Stock> topFiveStockByCompanyRanking() {
        return stockservice.topFiveStockByCompanyRanking();
        
    }

}

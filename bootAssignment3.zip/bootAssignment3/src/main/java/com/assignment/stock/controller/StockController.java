package com.assignment.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.assignment.stock.model.Stock;
import com.assignment.stock.service.StockService;

public class StockController {
	@Autowired
	StockService stockservice;
	
	

	@GetMapping(value = "/getAllStock")
	ResponseEntity<Iterable<Stock> > getAllStock() {
        return ResponseEntity.ok(this.stockservice.findAllStock());
    }
	@GetMapping(value = "/topFive")
	ResponseEntity<Iterable<Stock>> topFiveStockByPrice() {
        return ResponseEntity.ok(this.stockservice.topFiveStock());
    }
	@GetMapping(value = "/topFiveStockByCompanyRanking")
	ResponseEntity<Iterable<Stock>> topFiveStockByCompanyRanking() {
        return ResponseEntity.ok(this.stockservice.topFiveStockByCompanyRanking());
    }
	@PostMapping(value ="/searchStockByCompany/{companyName}")
	ResponseEntity<Iterable<Stock>> searchStockByCompany(@PathVariable String companyName) {
        return ResponseEntity.ok(this.stockservice.stockByCompanyName(companyName));
    }
	
	
	
	
    

}
